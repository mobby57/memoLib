globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/ba295689715ef1d9.js",
    "static/chunks/5f20bcef6fd83517.js",
    "static/chunks/f0bf7a06365fc174.js",
    "static/chunks/9fe85b65cc1c677a.js",
    "static/chunks/turbopack-83d372c1b4fd2394.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];