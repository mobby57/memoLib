1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/6efbf8097aa7f373.js"],"default"]
3:I[837457,["/_next/static/chunks/6efbf8097aa7f373.js"],"default"]
0:{"buildId":"Dmt2fc8RAGi-97QFj1A26","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
