module.exports=[260572,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_tenant_%5BtenantId%5D_predictions_route_actions_7b4be957.js.map