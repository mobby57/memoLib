module.exports=[9616,(e,o,d)=>{}];

//# sourceMappingURL=bec2d_app_api_workspace-reasoning_%5Bid%5D_contexts_%5BcontextId%5D_route_actions_b08e9cf8.js.map