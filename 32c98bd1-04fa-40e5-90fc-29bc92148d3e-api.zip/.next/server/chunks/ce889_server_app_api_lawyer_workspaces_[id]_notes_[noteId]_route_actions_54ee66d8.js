module.exports=[685168,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_lawyer_workspaces_%5Bid%5D_notes_%5BnoteId%5D_route_actions_54ee66d8.js.map