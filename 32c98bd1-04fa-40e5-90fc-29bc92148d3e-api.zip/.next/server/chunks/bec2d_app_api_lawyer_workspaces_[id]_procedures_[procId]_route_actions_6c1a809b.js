module.exports=[237526,(e,o,d)=>{}];

//# sourceMappingURL=bec2d_app_api_lawyer_workspaces_%5Bid%5D_procedures_%5BprocId%5D_route_actions_6c1a809b.js.map