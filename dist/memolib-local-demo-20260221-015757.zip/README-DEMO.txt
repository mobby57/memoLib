﻿MemoLib.Api - Demo locale

Option A (portable):
1) Double-cliquez run-demo.bat
2) Le script choisit automatiquement un port libre entre 8091 et 8100
3) VÃ©rifiez l'URL /health affichÃ©e dans la console

Option B (installer local):
1) Double-cliquez install-demo.bat
2) Lancez "MemoLib Demo" depuis le Bureau
3) Pour supprimer, exÃ©cutez uninstall-demo.bat

La base est stockÃ©e ici:
%LOCALAPPDATA%\MemoLib\memolib.demo.db

HTTPS redirection est dÃ©sactivÃ©e en mode dÃ©mo locale.
