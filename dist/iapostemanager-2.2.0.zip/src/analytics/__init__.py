"""Modules analytics - Dashboard, Notifications"""
