"""Modules IA - Génération, Analyse, Vocal"""
