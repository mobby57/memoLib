"""Module d'accessibilité pour personnes sourdes, muettes et aveugles"""
