"""Modules utilisateur - Auth, Registration, Management"""
