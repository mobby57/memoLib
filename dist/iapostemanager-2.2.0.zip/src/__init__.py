"""SecureVault - Email Automation System"""
__version__ = "2.0.0"
