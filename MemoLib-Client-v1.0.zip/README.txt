MEMOLIB - INSTALLATION CLIENT

Prerequis:
- Windows 10/11
- .NET 9.0 SDK

Installation:
1. Executer: install.ps1
2. Suivre les instructions
3. Lancer: demarrer.ps1

Acces:
http://localhost:5078/demo.html

Support:
Email: support@ms-conseils.fr
Tel: 03 87 XX XX XX