var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__72e5edfb._.js")
R.c("server/chunks/[root-of-the-server]__c270f14a._.js")
R.m(489997)
module.exports=R.m(489997).exports
