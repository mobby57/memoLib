module.exports=[659120,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_client_demandes_route_actions_54a95ac3.js.map