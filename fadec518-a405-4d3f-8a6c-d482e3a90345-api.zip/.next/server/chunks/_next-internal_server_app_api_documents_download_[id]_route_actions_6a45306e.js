module.exports=[645447,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_documents_download_%5Bid%5D_route_actions_6a45306e.js.map