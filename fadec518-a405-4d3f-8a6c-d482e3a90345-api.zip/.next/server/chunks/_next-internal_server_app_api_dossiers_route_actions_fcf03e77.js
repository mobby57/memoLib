module.exports=[325425,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dossiers_route_actions_fcf03e77.js.map