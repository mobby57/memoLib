module.exports=[414015,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dashboard_monthly-data_route_actions_74c8b606.js.map