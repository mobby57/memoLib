module.exports=[25222,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_client_profil_route_actions_9e8e18c2.js.map