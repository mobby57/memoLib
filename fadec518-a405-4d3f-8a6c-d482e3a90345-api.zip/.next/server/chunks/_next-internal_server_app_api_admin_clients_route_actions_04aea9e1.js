module.exports=[996799,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_clients_route_actions_04aea9e1.js.map