module.exports=[881712,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_github_user_route_actions_21b04d8c.js.map