module.exports=[377332,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dashboard_recent-activities_route_actions_9a66c381.js.map