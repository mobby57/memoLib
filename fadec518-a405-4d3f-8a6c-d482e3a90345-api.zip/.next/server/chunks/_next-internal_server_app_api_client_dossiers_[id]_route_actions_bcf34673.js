module.exports=[682391,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_client_dossiers_%5Bid%5D_route_actions_bcf34673.js.map