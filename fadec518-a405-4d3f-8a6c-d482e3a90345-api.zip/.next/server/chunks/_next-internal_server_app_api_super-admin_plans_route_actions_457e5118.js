module.exports=[354188,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_super-admin_plans_route_actions_457e5118.js.map