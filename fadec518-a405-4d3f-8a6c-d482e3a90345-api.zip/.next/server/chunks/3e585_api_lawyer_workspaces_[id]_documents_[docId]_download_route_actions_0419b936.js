module.exports=[205908,(e,o,d)=>{}];

//# sourceMappingURL=3e585_api_lawyer_workspaces_%5Bid%5D_documents_%5BdocId%5D_download_route_actions_0419b936.js.map