module.exports=[866418,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_profil_route_actions_30f337e7.js.map