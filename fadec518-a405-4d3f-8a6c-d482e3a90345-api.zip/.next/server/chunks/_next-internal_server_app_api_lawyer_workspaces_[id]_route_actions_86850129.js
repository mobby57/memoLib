module.exports=[359442,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_lawyer_workspaces_%5Bid%5D_route_actions_86850129.js.map