module.exports=[261254,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_tenant_%5BtenantId%5D_quick-actions_route_actions_24a36d79.js.map