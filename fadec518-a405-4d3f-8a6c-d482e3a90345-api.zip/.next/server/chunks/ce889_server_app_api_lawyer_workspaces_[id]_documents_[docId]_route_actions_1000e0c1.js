module.exports=[429719,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_lawyer_workspaces_%5Bid%5D_documents_%5BdocId%5D_route_actions_1000e0c1.js.map