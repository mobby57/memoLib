module.exports=[532521,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_forms_resource-request_route_actions_10401987.js.map