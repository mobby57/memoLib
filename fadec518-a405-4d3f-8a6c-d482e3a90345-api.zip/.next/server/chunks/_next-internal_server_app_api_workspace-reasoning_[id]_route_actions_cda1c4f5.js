module.exports=[457984,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_workspace-reasoning_%5Bid%5D_route_actions_cda1c4f5.js.map