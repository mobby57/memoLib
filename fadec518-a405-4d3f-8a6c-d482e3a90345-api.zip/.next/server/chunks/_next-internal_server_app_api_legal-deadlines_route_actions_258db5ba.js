module.exports=[23547,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_legal-deadlines_route_actions_258db5ba.js.map