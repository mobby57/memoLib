module.exports=[912383,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_search_analytics_route_actions_07e7b9ba.js.map