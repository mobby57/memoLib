module.exports=[325648,a=>{"use strict";function b({children:a}){return a}a.s(["default",()=>b,"dynamic",0,"force-dynamic","runtime",0,"nodejs"])}];

//# sourceMappingURL=src_app_lawyer_layout_tsx_85ba293b._.js.map