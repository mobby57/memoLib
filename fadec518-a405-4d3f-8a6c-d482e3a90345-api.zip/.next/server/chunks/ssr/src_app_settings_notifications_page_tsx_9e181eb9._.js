module.exports=[678200,a=>{"use strict";var b=a.i(187924),c=a.i(572131),d=a.i(62067);a.i(111909);var e=a.i(614490),f=a.i(731419);a.i(833828);var g=a.i(627604),h=a.i(523312),i=a.i(992258),j=a.i(641710),k=a.i(816201),l=a.i(692759),m=a.i(501027),n=a.i(941675),o=a.i(787405),p=a.i(255145);let q={enabled:!0,triggers:{echeances:{enabled:!0,daysBefore:[7,3,1]},facturesOverdue:{enabled:!0,daysAfter:[7,14,30]},weeklySummary:{enabled:!0,dayOfWeek:1,hour:9}}};async function r(a){return p.logger.info("Email simule envoye",{to:a.to.map(a=>a.email),subject:a.template.subject,from:"noreply@iapostemanage.com"}),!0}a.i(350889);var s=a.i(918604);function t(){let{showToast:a}=(0,s.useToast)(),[p,t]=(0,c.useState)(q),[u,v]=(0,c.useState)(!1),w=a=>{t(b=>{let c={...b},d=c;for(let b=0;b<a.length-1;b++)d=d[a[b]];return d[a[a.length-1]]=!d[a[a.length-1]],c})},x=async()=>{v(!0),await new Promise(a=>setTimeout(a,500)),o.safeLocalStorage.setItem("notification_config",JSON.stringify(p)),a("Parametres de notification sauvegardes","success"),v(!1)},y=async b=>{var c,d,e;let f,g,h,i,j;switch(b){case"echeance":c={titre:"Depot des conclusions",date:new Date(Date.now()+2592e5),dossier:"DOS-2026-001",description:"Depot des conclusions au greffe du tribunal"},g="Important",h=`${g}: echeance dans 3 jours - ${c.titre}`,f={subject:h,htmlBody:`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f3f4f6;">
      <div style="max-width: 600px; margin: 0 auto; background-color: white;">
        <!-- Header -->
        <div style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); padding: 30px; text-align: center;">
          <h1 style="color: white; margin: 0; font-size: 24px;">Rappel d'echeance</h1>
        </div>

        <!-- Alert Banner -->
        <div style="background-color: #f59e0b; color: white; padding: 15px; text-align: center; font-weight: bold;">
          ️ ${g}: 3 jours restants
        </div>

        <!-- Content -->
        <div style="padding: 30px;">
          <h2 style="color: #1f2937; margin-top: 0;">${c.titre}</h2>
          
          <div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="padding: 8px 0; color: #6b7280; width: 30%;">[emoji] Date:</td>
                <td style="padding: 8px 0; color: #1f2937; font-weight: bold;">
                  ${c.date.toLocaleDateString("fr-FR",{weekday:"long",year:"numeric",month:"long",day:"numeric"})}
                </td>
              </tr>
              <tr>
                <td style="padding: 8px 0; color: #6b7280;">[emoji] Dossier:</td>
                <td style="padding: 8px 0; color: #1f2937; font-weight: bold;">${c.dossier}</td>
              </tr>
              ${c.description?`
              <tr>
                <td colspan="2" style="padding: 8px 0; color: #6b7280;">
                  <br>
                  [emoji] Description:<br>
                  <span style="color: #1f2937;">${c.description}</span>
                </td>
              </tr>
              `:""}
            </table>
          </div>

          <div style="background-color: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0;">
            <strong style="color: #92400e;">Action requise:</strong>
            <p style="color: #78350f; margin: 8px 0 0 0;">
              N'oubliez pas de traiter cette echeance avant la date limite.
            </p>
          </div>

          <div style="text-align: center; margin-top: 30px;">
            <a href="http://localhost:3000/calendrier" 
               style="background-color: #3b82f6; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: bold;">
              Voir le calendrier
            </a>
          </div>
        </div>

        <!-- Footer -->
        <div style="background-color: #f9fafb; padding: 20px; text-align: center; border-top: 1px solid #e5e7eb;">
          <p style="color: #6b7280; font-size: 12px; margin: 0;">
            Cet email a ete genere automatiquement par IA Poste Manager<br>
            Pour modifier vos preferences de notification, rendez-vous dans les parametres.
          </p>
        </div>
      </div>
    </body>
    </html>
  `,textBody:`
${g}: echeance dans 3 jours

${c.titre}

Date: ${c.date.toLocaleDateString("fr-FR")}
Dossier: ${c.dossier}
${c.description?`
Description: ${c.description}`:""}

N'oubliez pas de traiter cette echeance avant la date limite.

Voir le calendrier: http://localhost:3000/calendrier
  `.trim()};break;case"facture":d={numero:"FACT-2026-001",client:"Martin Dupont",montant:1500,dateEcheance:new Date(Date.now()-6048e5)},i=`Rappel: Facture ${d.numero} en retard (7 jours)`,f={subject:i,htmlBody:`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f3f4f6;">
      <div style="max-width: 600px; margin: 0 auto; background-color: white;">
        <div style="background: linear-gradient(135deg, #dc2626 0%, #991b1b 100%); padding: 30px; text-align: center;">
          <h1 style="color: white; margin: 0; font-size: 24px;">️ Facture Impayee</h1>
        </div>

        <div style="padding: 30px;">
          <h2 style="color: #1f2937;">Relance de paiement</h2>
          
          <p style="color: #4b5563; line-height: 1.6;">
            La facture suivante est en retard de paiement depuis <strong>7 jours</strong>:
          </p>

          <div style="background-color: #fee2e2; padding: 20px; border-radius: 8px; border-left: 4px solid #dc2626; margin: 20px 0;">
            <table style="width: 100%;">
              <tr>
                <td style="color: #6b7280; padding: 5px 0;">Numero:</td>
                <td style="color: #1f2937; font-weight: bold; padding: 5px 0;">${d.numero}</td>
              </tr>
              <tr>
                <td style="color: #6b7280; padding: 5px 0;">Client:</td>
                <td style="color: #1f2937; font-weight: bold; padding: 5px 0;">${d.client}</td>
              </tr>
              <tr>
                <td style="color: #6b7280; padding: 5px 0;">Montant:</td>
                <td style="color: #dc2626; font-weight: bold; font-size: 18px; padding: 5px 0;">${d.montant.toFixed(2)} €</td>
              </tr>
              <tr>
                <td style="color: #6b7280; padding: 5px 0;">echeance:</td>
                <td style="color: #1f2937; padding: 5px 0;">${d.dateEcheance.toLocaleDateString("fr-FR")}</td>
              </tr>
            </table>
          </div>

          <p style="color: #4b5563; line-height: 1.6;">
            <strong>Actions recommandees:</strong>
          </p>
          <ul style="color: #4b5563; line-height: 1.8;">
            <li>Contacter le client pour relance</li>
            <li>Verifier le statut de paiement</li>
            <li>Envoyer un rappel de paiement</li>
          </ul>

          <div style="text-align: center; margin-top: 30px;">
            <a href="http://localhost:3000/factures" 
               style="background-color: #dc2626; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: bold;">
              Voir la facture
            </a>
          </div>
        </div>

        <div style="background-color: #f9fafb; padding: 20px; text-align: center; border-top: 1px solid #e5e7eb;">
          <p style="color: #6b7280; font-size: 12px; margin: 0;">
            IA Poste Manager - Gestion intelligente de cabinet juridique
          </p>
        </div>
      </div>
    </body>
    </html>
  `,textBody:`
Rappel: Facture ${d.numero} en retard (7 jours)

La facture suivante est en retard de paiement:

Numero: ${d.numero}
Client: ${d.client}
Montant: ${d.montant.toFixed(2)} €
echeance: ${d.dateEcheance.toLocaleDateString("fr-FR")}

Actions recommandees:
- Contacter le client pour relance
- Verifier le statut de paiement
- Envoyer un rappel de paiement

Voir la facture: http://localhost:3000/factures
  `.trim()};break;case"summary":e={newDossiers:5,newFactures:8,totalRevenue:12500,upcomingEcheances:3,overdueFactures:2},j=`Resume hebdomadaire - Semaine du ${new Date().toLocaleDateString("fr-FR")}`,f={subject:j,htmlBody:`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f3f4f6;">
      <div style="max-width: 600px; margin: 0 auto; background-color: white;">
        <div style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); padding: 30px; text-align: center;">
          <h1 style="color: white; margin: 0; font-size: 24px;">[emoji] Resume Hebdomadaire</h1>
          <p style="color: #dbeafe; margin: 10px 0 0 0;">Semaine du ${new Date().toLocaleDateString("fr-FR")}</p>
        </div>

        <div style="padding: 30px;">
          <h2 style="color: #1f2937; margin-top: 0;">Votre activite cette semaine</h2>

          <!-- Stats Grid -->
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0;">
            <div style="background-color: #eff6ff; padding: 20px; border-radius: 8px; text-align: center;">
              <div style="color: #3b82f6; font-size: 32px; font-weight: bold;">${e.newDossiers}</div>
              <div style="color: #1e40af; font-size: 14px; margin-top: 5px;">Nouveaux dossiers</div>
            </div>
            <div style="background-color: #f0fdf4; padding: 20px; border-radius: 8px; text-align: center;">
              <div style="color: #22c55e; font-size: 32px; font-weight: bold;">${e.totalRevenue.toFixed(0)} €</div>
              <div style="color: #16a34a; font-size: 14px; margin-top: 5px;">Chiffre d'affaires</div>
            </div>
            <div style="background-color: #fef3c7; padding: 20px; border-radius: 8px; text-align: center;">
              <div style="color: #f59e0b; font-size: 32px; font-weight: bold;">${e.upcomingEcheances}</div>
              <div style="color: #d97706; font-size: 14px; margin-top: 5px;">echeances a venir</div>
            </div>
            <div style="background-color: #fee2e2; padding: 20px; border-radius: 8px; text-align: center;">
              <div style="color: #ef4444; font-size: 32px; font-weight: bold;">${e.overdueFactures}</div>
              <div style="color: #dc2626; font-size: 14px; margin-top: 5px;">Factures en retard</div>
            </div>
          </div>

          ${e.overdueFactures>0?`
          <div style="background-color: #fee2e2; border-left: 4px solid #dc2626; padding: 15px; margin: 20px 0;">
            <strong style="color: #991b1b;">️ Action requise:</strong>
            <p style="color: #7f1d1d; margin: 8px 0 0 0;">
              Vous avez ${e.overdueFactures} facture${e.overdueFactures>1?"s":""} en retard de paiement.
            </p>
          </div>
          `:""}

          <div style="text-align: center; margin-top: 30px;">
            <a href="http://localhost:3000/dashboard" 
               style="background-color: #3b82f6; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: bold;">
              Voir le dashboard
            </a>
          </div>
        </div>

        <div style="background-color: #f9fafb; padding: 20px; text-align: center; border-top: 1px solid #e5e7eb;">
          <p style="color: #6b7280; font-size: 12px; margin: 0;">
            IA Poste Manager - Resume automatique hebdomadaire<br>
            Pour desactiver ces emails, rendez-vous dans les parametres.
          </p>
        </div>
      </div>
    </body>
    </html>
  `,textBody:`
Resume hebdomadaire - ${new Date().toLocaleDateString("fr-FR")}

Votre activite cette semaine:

[emoji] ${e.newDossiers} nouveaux dossiers
[emoji] ${e.totalRevenue.toFixed(2)} € de chiffre d'affaires
[emoji] ${e.upcomingEcheances} echeances a venir
️ ${e.overdueFactures} factures en retard

Voir le dashboard: http://localhost:3000/dashboard
  `.trim()}}await r({to:[{email:"user@example.com",name:"Utilisateur Test"}],template:f}),a("Email de test envoye (verifiez la console)","success")};return(0,b.jsxs)("div",{className:"p-6 max-w-7xl mx-auto",children:[(0,b.jsx)(e.Breadcrumb,{items:[{label:"Dashboard",href:"/dashboard"},{label:"Parametres",href:"/settings"},{label:"Notifications",href:"/settings/notifications"}]}),(0,b.jsxs)("div",{className:"mb-6",children:[(0,b.jsx)("h1",{className:"text-3xl font-bold text-gray-900 dark:text-white mb-2",children:"Notifications Automatiques"}),(0,b.jsx)("p",{className:"text-gray-600 dark:text-gray-400",children:"Configurez les rappels et alertes par email"})]}),(0,b.jsxs)(f.Alert,{variant:"info",className:"mb-6",children:[(0,b.jsx)(h.Bell,{className:"h-5 w-5"}),"Les notifications sont envoyees automatiquement selon vos preferences. Vous pouvez tester chaque type de notification ci-dessous."]}),(0,b.jsx)(d.Card,{className:"p-6 mb-6",children:(0,b.jsxs)("div",{className:"flex items-center justify-between",children:[(0,b.jsxs)("div",{className:"flex items-center gap-4",children:[(0,b.jsx)("div",{className:`p-4 rounded-full ${p.enabled?"bg-green-100 dark:bg-green-900/30":"bg-gray-100 dark:bg-gray-800"}`,children:p.enabled?(0,b.jsx)(k.CheckCircle,{className:"h-8 w-8 text-green-600 dark:text-green-400"}):(0,b.jsx)(h.Bell,{className:"h-8 w-8 text-gray-400"})}),(0,b.jsxs)("div",{children:[(0,b.jsxs)("h2",{className:"text-xl font-semibold text-gray-900 dark:text-white",children:["Notifications ",p.enabled?"activees":"desactivees"]}),(0,b.jsx)("p",{className:"text-sm text-gray-600 dark:text-gray-400",children:p.enabled?"Les emails automatiques seront envoyes selon votre configuration":"Aucun email automatique ne sera envoye"})]})]}),(0,b.jsx)("button",{onClick:()=>w(["enabled"]),className:`relative inline-flex h-8 w-14 items-center rounded-full transition-colors ${p.enabled?"bg-blue-600":"bg-gray-300 dark:bg-gray-600"}`,children:(0,b.jsx)("span",{className:`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${p.enabled?"translate-x-7":"translate-x-1"}`})})]})}),(0,b.jsxs)(d.Card,{className:"p-6 mb-6",children:[(0,b.jsxs)("div",{className:"flex items-center justify-between mb-4",children:[(0,b.jsxs)("div",{className:"flex items-center gap-3",children:[(0,b.jsx)("div",{className:"p-3 bg-red-100 dark:bg-red-900/30 rounded-lg",children:(0,b.jsx)(j.Clock,{className:"h-6 w-6 text-red-600 dark:text-red-400"})}),(0,b.jsxs)("div",{children:[(0,b.jsx)("h3",{className:"text-lg font-semibold text-gray-900 dark:text-white",children:"Rappels d'echeances"}),(0,b.jsx)("p",{className:"text-sm text-gray-600 dark:text-gray-400",children:"Recevez des rappels avant les dates limites importantes"})]})]}),(0,b.jsx)("button",{onClick:()=>w(["triggers","echeances","enabled"]),className:`relative inline-flex h-8 w-14 items-center rounded-full transition-colors ${p.triggers.echeances.enabled?"bg-blue-600":"bg-gray-300 dark:bg-gray-600"}`,children:(0,b.jsx)("span",{className:`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${p.triggers.echeances.enabled?"translate-x-7":"translate-x-1"}`})})]}),p.triggers.echeances.enabled&&(0,b.jsxs)("div",{className:"space-y-3 pl-12",children:[(0,b.jsx)("p",{className:"text-sm text-gray-700 dark:text-gray-300",children:"Rappels envoyes avant l'echeance:"}),(0,b.jsx)("div",{className:"flex flex-wrap gap-2",children:p.triggers.echeances.daysBefore.map(a=>(0,b.jsxs)("span",{className:"px-3 py-1 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-full text-sm",children:[a," jour",a>1?"s":""," avant"]},a))}),(0,b.jsxs)(g.Button,{variant:"secondary",size:"sm",onClick:()=>y("echeance"),className:"mt-3",children:[(0,b.jsx)(l.Send,{className:"h-4 w-4 mr-2"}),"Tester un rappel"]})]})]}),(0,b.jsxs)(d.Card,{className:"p-6 mb-6",children:[(0,b.jsxs)("div",{className:"flex items-center justify-between mb-4",children:[(0,b.jsxs)("div",{className:"flex items-center gap-3",children:[(0,b.jsx)("div",{className:"p-3 bg-orange-100 dark:bg-orange-900/30 rounded-lg",children:(0,b.jsx)(i.Mail,{className:"h-6 w-6 text-orange-600 dark:text-orange-400"})}),(0,b.jsxs)("div",{children:[(0,b.jsx)("h3",{className:"text-lg font-semibold text-gray-900 dark:text-white",children:"Relances factures impayees"}),(0,b.jsx)("p",{className:"text-sm text-gray-600 dark:text-gray-400",children:"Alertes automatiques pour les factures en retard"})]})]}),(0,b.jsx)("button",{onClick:()=>w(["triggers","facturesOverdue","enabled"]),className:`relative inline-flex h-8 w-14 items-center rounded-full transition-colors ${p.triggers.facturesOverdue.enabled?"bg-blue-600":"bg-gray-300 dark:bg-gray-600"}`,children:(0,b.jsx)("span",{className:`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${p.triggers.facturesOverdue.enabled?"translate-x-7":"translate-x-1"}`})})]}),p.triggers.facturesOverdue.enabled&&(0,b.jsxs)("div",{className:"space-y-3 pl-12",children:[(0,b.jsx)("p",{className:"text-sm text-gray-700 dark:text-gray-300",children:"Relances envoyees apres l'echeance:"}),(0,b.jsx)("div",{className:"flex flex-wrap gap-2",children:p.triggers.facturesOverdue.daysAfter.map(a=>(0,b.jsxs)("span",{className:"px-3 py-1 bg-orange-50 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 rounded-full text-sm",children:[a," jour",a>1?"s":""," apres"]},a))}),(0,b.jsxs)(g.Button,{variant:"secondary",size:"sm",onClick:()=>y("facture"),className:"mt-3",children:[(0,b.jsx)(l.Send,{className:"h-4 w-4 mr-2"}),"Tester une relance"]})]})]}),(0,b.jsxs)(d.Card,{className:"p-6 mb-6",children:[(0,b.jsxs)("div",{className:"flex items-center justify-between mb-4",children:[(0,b.jsxs)("div",{className:"flex items-center gap-3",children:[(0,b.jsx)("div",{className:"p-3 bg-purple-100 dark:bg-purple-900/30 rounded-lg",children:(0,b.jsx)(n.Calendar,{className:"h-6 w-6 text-purple-600 dark:text-purple-400"})}),(0,b.jsxs)("div",{children:[(0,b.jsx)("h3",{className:"text-lg font-semibold text-gray-900 dark:text-white",children:"Resume hebdomadaire"}),(0,b.jsx)("p",{className:"text-sm text-gray-600 dark:text-gray-400",children:"Synthese de votre activite chaque semaine"})]})]}),(0,b.jsx)("button",{onClick:()=>w(["triggers","weeklySummary","enabled"]),className:`relative inline-flex h-8 w-14 items-center rounded-full transition-colors ${p.triggers.weeklySummary.enabled?"bg-blue-600":"bg-gray-300 dark:bg-gray-600"}`,children:(0,b.jsx)("span",{className:`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${p.triggers.weeklySummary.enabled?"translate-x-7":"translate-x-1"}`})})]}),p.triggers.weeklySummary.enabled&&(0,b.jsxs)("div",{className:"space-y-3 pl-12",children:[(0,b.jsxs)("p",{className:"text-sm text-gray-700 dark:text-gray-300",children:["Envoye chaque ",["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"][p.triggers.weeklySummary.dayOfWeek]," a ",p.triggers.weeklySummary.hour,"h00"]}),(0,b.jsxs)(g.Button,{variant:"secondary",size:"sm",onClick:()=>y("summary"),className:"mt-3",children:[(0,b.jsx)(l.Send,{className:"h-4 w-4 mr-2"}),"Tester le resume"]})]})]}),(0,b.jsxs)("div",{className:"flex justify-end gap-3",children:[(0,b.jsx)(g.Button,{variant:"secondary",onClick:()=>t(q),children:"Reinitialiser"}),(0,b.jsx)(g.Button,{onClick:x,disabled:u,children:u?(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(m.Zap,{className:"h-4 w-4 mr-2 animate-spin"}),"Sauvegarde..."]}):(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(k.CheckCircle,{className:"h-4 w-4 mr-2"}),"Sauvegarder les parametres"]})})]}),(0,b.jsxs)(d.Card,{className:"p-6 mt-6 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800",children:[(0,b.jsxs)("h4",{className:"font-semibold text-blue-900 dark:text-blue-100 mb-3 flex items-center gap-2",children:[(0,b.jsx)(m.Zap,{className:"h-5 w-5"}),"Mode developpement"]}),(0,b.jsx)("p",{className:"text-sm text-blue-800 dark:text-blue-200 mb-3",children:"Les emails sont actuellement simules (affiches dans la console). En production, ils seront envoyes via un service d'emailing."}),(0,b.jsxs)("div",{className:"text-xs text-blue-700 dark:text-blue-300 space-y-1",children:[(0,b.jsxs)("p",{children:["- ",(0,b.jsx)("strong",{children:"Services recommandes:"})," Resend, SendGrid, AWS SES, Mailgun"]}),(0,b.jsxs)("p",{children:["- ",(0,b.jsx)("strong",{children:"Configuration:"})," Definir la cle API dans les variables d'environnement"]}),(0,b.jsxs)("p",{children:["- ",(0,b.jsx)("strong",{children:"Personnalisation:"})," Les templates HTML peuvent etre modifies dans ",(0,b.jsx)("code",{className:"bg-blue-100 dark:bg-blue-900/50 px-1 rounded",children:"emailService.ts"})]})]})]})]})}a.s(["default",()=>t,"dynamic",0,"force-dynamic"],678200)}];

//# sourceMappingURL=src_app_settings_notifications_page_tsx_9e181eb9._.js.map