module.exports=[215025,a=>{"use strict";function b({children:a}){return a}a.s(["default",()=>b,"dynamic",0,"force-dynamic","runtime",0,"nodejs"])}];

//# sourceMappingURL=src_app_super-admin_layout_tsx_0ae88321._.js.map