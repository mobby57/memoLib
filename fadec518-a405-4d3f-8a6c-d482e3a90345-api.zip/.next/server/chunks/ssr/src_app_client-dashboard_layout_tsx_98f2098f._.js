module.exports=[959331,a=>{"use strict";function b({children:a}){return a}a.s(["default",()=>b,"dynamic",0,"force-dynamic","runtime",0,"nodejs"])}];

//# sourceMappingURL=src_app_client-dashboard_layout_tsx_98f2098f._.js.map