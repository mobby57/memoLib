module.exports=[436102,a=>{"use strict";function b({children:a}){return a}a.s(["default",()=>b,"dynamic",0,"force-dynamic","runtime",0,"nodejs"])}];

//# sourceMappingURL=src_app_admin_layout_tsx_9cb4d248._.js.map