module.exports=[631546,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_client_my-factures_route_actions_4aef506b.js.map