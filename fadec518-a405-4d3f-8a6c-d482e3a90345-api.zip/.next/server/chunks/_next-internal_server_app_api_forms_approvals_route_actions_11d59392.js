module.exports=[274037,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_forms_approvals_route_actions_11d59392.js.map