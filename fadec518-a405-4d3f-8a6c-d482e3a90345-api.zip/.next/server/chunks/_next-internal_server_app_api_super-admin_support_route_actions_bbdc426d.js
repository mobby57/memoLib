module.exports=[289435,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_super-admin_support_route_actions_bbdc426d.js.map