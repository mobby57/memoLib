module.exports=[751225,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_github_sync-dossier_route_actions_3925cf9c.js.map