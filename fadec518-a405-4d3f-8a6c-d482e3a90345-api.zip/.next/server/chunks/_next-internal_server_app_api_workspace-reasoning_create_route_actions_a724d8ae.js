module.exports=[763963,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_workspace-reasoning_create_route_actions_a724d8ae.js.map