module.exports=[572056,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_lawyer_workspace_%5Bid%5D_route_actions_5ff6218d.js.map