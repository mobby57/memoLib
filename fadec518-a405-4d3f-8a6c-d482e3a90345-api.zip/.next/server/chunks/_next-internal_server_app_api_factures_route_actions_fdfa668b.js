module.exports=[91792,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_factures_route_actions_fdfa668b.js.map