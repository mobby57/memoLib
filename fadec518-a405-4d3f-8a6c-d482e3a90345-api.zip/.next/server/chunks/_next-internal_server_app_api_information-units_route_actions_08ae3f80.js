module.exports=[954737,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_information-units_route_actions_08ae3f80.js.map