module.exports=[56009,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_client_messages_mark-read_route_actions_4c4f107d.js.map