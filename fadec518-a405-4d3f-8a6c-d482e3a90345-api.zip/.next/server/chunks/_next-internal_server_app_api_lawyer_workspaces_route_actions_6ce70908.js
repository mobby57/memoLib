module.exports=[381456,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_lawyer_workspaces_route_actions_6ce70908.js.map