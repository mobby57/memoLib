module.exports=[829726,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_client_my-dossiers_route_actions_d1086d22.js.map