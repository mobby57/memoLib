module.exports=[886898,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_proofs_route_actions_0558093b.js.map