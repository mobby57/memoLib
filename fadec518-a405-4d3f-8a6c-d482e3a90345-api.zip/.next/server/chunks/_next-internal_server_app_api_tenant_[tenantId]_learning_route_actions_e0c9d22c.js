module.exports=[565039,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_tenant_%5BtenantId%5D_learning_route_actions_e0c9d22c.js.map