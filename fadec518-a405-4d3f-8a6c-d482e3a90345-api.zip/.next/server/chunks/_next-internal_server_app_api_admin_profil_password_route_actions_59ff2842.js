module.exports=[344460,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_profil_password_route_actions_59ff2842.js.map