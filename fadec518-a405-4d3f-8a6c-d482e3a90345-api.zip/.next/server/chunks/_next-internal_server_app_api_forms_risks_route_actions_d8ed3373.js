module.exports=[936851,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_forms_risks_route_actions_d8ed3373.js.map