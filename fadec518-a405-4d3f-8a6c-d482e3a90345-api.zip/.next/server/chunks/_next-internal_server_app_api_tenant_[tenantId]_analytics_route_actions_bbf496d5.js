module.exports=[895100,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_tenant_%5BtenantId%5D_analytics_route_actions_bbf496d5.js.map