module.exports=[119920,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_dossiers_%5Bid%5D_route_actions_28b1b590.js.map