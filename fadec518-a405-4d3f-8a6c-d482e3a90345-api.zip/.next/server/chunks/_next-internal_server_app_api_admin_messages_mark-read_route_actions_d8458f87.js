module.exports=[904668,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_messages_mark-read_route_actions_d8458f87.js.map