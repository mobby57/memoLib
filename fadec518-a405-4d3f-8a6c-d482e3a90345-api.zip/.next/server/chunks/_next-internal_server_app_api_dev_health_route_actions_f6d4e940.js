module.exports=[837348,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_dev_health_route_actions_f6d4e940.js.map