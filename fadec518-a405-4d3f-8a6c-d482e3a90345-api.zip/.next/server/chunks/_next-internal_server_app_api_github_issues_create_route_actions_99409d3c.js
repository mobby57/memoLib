module.exports=[600857,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_github_issues_create_route_actions_99409d3c.js.map