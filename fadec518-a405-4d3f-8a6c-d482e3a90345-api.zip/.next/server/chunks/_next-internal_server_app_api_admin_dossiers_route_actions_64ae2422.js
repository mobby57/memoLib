module.exports=[905994,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_dossiers_route_actions_64ae2422.js.map