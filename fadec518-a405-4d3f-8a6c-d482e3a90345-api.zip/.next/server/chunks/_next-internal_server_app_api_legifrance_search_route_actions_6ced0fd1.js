module.exports=[935717,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_legifrance_search_route_actions_6ced0fd1.js.map