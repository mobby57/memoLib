module.exports=[787360,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_client_dossiers_route_actions_e381d800.js.map