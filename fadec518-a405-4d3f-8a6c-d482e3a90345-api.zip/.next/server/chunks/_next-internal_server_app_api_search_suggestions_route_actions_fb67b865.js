module.exports=[595164,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_search_suggestions_route_actions_fb67b865.js.map