module.exports=[377034,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_forms_risk-assessment_route_actions_bcedcf59.js.map