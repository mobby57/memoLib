module.exports=[556563,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_tenant_%5BtenantId%5D_dashboard_monthly-data_route_actions_fb49b136.js.map