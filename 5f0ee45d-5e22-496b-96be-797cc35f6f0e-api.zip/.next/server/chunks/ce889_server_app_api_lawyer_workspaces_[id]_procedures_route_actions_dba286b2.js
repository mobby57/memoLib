module.exports=[335882,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_lawyer_workspaces_%5Bid%5D_procedures_route_actions_dba286b2.js.map