module.exports=[241539,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_lawyer_workspace_%5Bid%5D_resolve-missing_route_actions_523de063.js.map