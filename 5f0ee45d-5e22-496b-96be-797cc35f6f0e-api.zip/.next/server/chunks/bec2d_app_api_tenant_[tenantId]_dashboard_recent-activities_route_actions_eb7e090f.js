module.exports=[606766,(e,o,d)=>{}];

//# sourceMappingURL=bec2d_app_api_tenant_%5BtenantId%5D_dashboard_recent-activities_route_actions_eb7e090f.js.map