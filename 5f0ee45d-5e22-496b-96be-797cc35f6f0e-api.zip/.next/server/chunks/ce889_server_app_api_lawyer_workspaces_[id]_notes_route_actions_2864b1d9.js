module.exports=[84669,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_lawyer_workspaces_%5Bid%5D_notes_route_actions_2864b1d9.js.map