module.exports=[761259,(e,o,d)=>{}];

//# sourceMappingURL=bec2d_app_api_tenant_%5BtenantId%5D_clients_%5BclientId%5D_dossiers_route_actions_a835ec7a.js.map