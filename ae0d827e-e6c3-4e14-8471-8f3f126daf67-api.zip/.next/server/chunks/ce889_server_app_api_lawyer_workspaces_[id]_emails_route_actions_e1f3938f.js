module.exports=[55846,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_lawyer_workspaces_%5Bid%5D_emails_route_actions_e1f3938f.js.map