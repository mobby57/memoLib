module.exports=[476767,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_tenant_%5BtenantId%5D_suggestions_route_actions_bb49b63d.js.map