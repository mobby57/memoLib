module.exports=[978621,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_tenant_%5BtenantId%5D_dashboard_stats_route_actions_6c1241f6.js.map