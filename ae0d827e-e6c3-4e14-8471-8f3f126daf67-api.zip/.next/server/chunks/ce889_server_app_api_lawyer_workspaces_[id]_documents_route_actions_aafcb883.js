module.exports=[615847,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_lawyer_workspaces_%5Bid%5D_documents_route_actions_aafcb883.js.map