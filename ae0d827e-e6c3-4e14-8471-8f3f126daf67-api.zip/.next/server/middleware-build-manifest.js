globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/664adc71bc2617c2.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/d413ef7a3bc0cfe8.js",
    "static/chunks/956d411224e8600a.js",
    "static/chunks/b22c1ccb3fa9cda8.js",
    "static/chunks/25b2135b80f28155.js",
    "static/chunks/turbopack-38d9f0027a46ce6c.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];